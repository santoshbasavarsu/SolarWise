from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from .data import Standardizer, feature_columns, make_sequences
from .models import GRUForecaster, SequenceAutoencoder


# ============================================================
# CONFIGURATION
# ============================================================

@dataclass
class Config:
    target: str = "solar_power"
    lookback: int = 24
    hidden_size: int = 64
    epochs: int = 30
    batch_size: int = 64
    learning_rate: float = 1e-3


# ============================================================
# TRAINING FUNCTION
# ============================================================

def _train(
    model: nn.Module,
    x: torch.Tensor,
    y: torch.Tensor | None,
    config: Config
) -> None:

    model.train()

    if y is None:
        dataset = TensorDataset(x)
    else:
        dataset = TensorDataset(x, y)

    loader = DataLoader(
        dataset,
        batch_size=config.batch_size,
        shuffle=True
    )

    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=config.learning_rate
    )

    loss_fn = nn.MSELoss()

    for epoch in range(config.epochs):

        total_loss = 0.0

        for batch in loader:

            optimizer.zero_grad()

            if y is None:

                prediction = model(batch[0])

                loss = loss_fn(
                    prediction,
                    batch[0]
                )

            else:

                prediction = model(batch[0])

                loss = loss_fn(
                    prediction,
                    batch[1]
                )

            loss.backward()

            optimizer.step()

            total_loss += loss.item()

        average_loss = total_loss / len(loader)

        print(
            f"Epoch {epoch + 1:02d}/{config.epochs} "
            f"- Loss: {average_loss:.6f}"
        )


# ============================================================
# MAIN TRAINING PIPELINE
# ============================================================

def train(
    frame,
    config: Config
) -> dict:

    # --------------------------------------------------------
    # 1. Select features
    # --------------------------------------------------------

    columns = feature_columns(
        frame,
        config.target
    )

    target_index = columns.index(
        config.target
    )

    values = frame[
        columns
    ].to_numpy(
        dtype=np.float32
    )

    # --------------------------------------------------------
    # 2. Chronological 70 / 15 / 15 split
    # --------------------------------------------------------

    total_size = len(values)

    train_size = int(
        total_size * 0.70
    )

    validation_size = int(
        total_size * 0.85
    )

    print("\nDataset Split:")
    print(
        f"Total samples      : {total_size}"
    )
    print(
        f"Training samples   : {train_size}"
    )
    print(
        f"Validation samples : "
        f"{validation_size - train_size}"
    )
    print(
        f"Test samples       : "
        f"{total_size - validation_size}"
    )

    # --------------------------------------------------------
    # 3. Fit scaler ONLY on training data
    # --------------------------------------------------------

    scaler = Standardizer.fit(
        values[:train_size]
    )

    normalized = scaler.transform(
        values
    )

    # --------------------------------------------------------
    # 4. Create 24-hour temporal sequences
    # --------------------------------------------------------

    x, y = make_sequences(
        normalized,
        config.lookback,
        target_index
    )

    # The target of each sequence corresponds to:
    #
    # lookback, lookback + 1, ...
    #
    sequence_targets = np.arange(
        config.lookback,
        total_size
    )

    # --------------------------------------------------------
    # 5. Create chronological masks
    # --------------------------------------------------------

    train_mask = (
        sequence_targets < train_size
    )

    validation_mask = (
        (sequence_targets >= train_size)
        &
        (sequence_targets < validation_size)
    )

    test_mask = (
        sequence_targets >= validation_size
    )

    # --------------------------------------------------------
    # 6. Split sequences
    # --------------------------------------------------------

    x_train = x[train_mask]
    y_train = y[train_mask]

    x_validation = x[validation_mask]
    y_validation = y[validation_mask]

    x_test = x[test_mask]
    y_test = y[test_mask]

    print("\nSequence Split:")
    print(
        f"Training sequences   : {len(x_train)}"
    )
    print(
        f"Validation sequences : {len(x_validation)}"
    )
    print(
        f"Test sequences       : {len(x_test)}"
    )

    # --------------------------------------------------------
    # 7. Convert to PyTorch tensors
    # --------------------------------------------------------

    x_train = torch.tensor(
        x_train,
        dtype=torch.float32
    )

    y_train = torch.tensor(
        y_train,
        dtype=torch.float32
    )

    x_validation = torch.tensor(
        x_validation,
        dtype=torch.float32
    )

    y_validation = torch.tensor(
        y_validation,
        dtype=torch.float32
    )

    x_test = torch.tensor(
        x_test,
        dtype=torch.float32
    )

    y_test = torch.tensor(
        y_test,
        dtype=torch.float32
    )

    # --------------------------------------------------------
    # 8. Create GRU forecasting model
    # --------------------------------------------------------

    forecaster = GRUForecaster(
        x.shape[-1],
        config.hidden_size
    )

    # --------------------------------------------------------
    # 9. Create Autoencoder
    # --------------------------------------------------------

    autoencoder = SequenceAutoencoder(
        x.shape[-1],
        config.hidden_size // 2
    )

    # --------------------------------------------------------
    # 10. Train GRU
    # --------------------------------------------------------

    print(
        "\nTraining GRU Forecasting Model..."
    )

    _train(
        forecaster,
        x_train,
        y_train,
        config
    )

    # --------------------------------------------------------
    # 11. Train Autoencoder
    # --------------------------------------------------------

    print(
        "\nTraining Autoencoder..."
    )

    _train(
        autoencoder,
        x_train,
        None,
        config
    )

    # --------------------------------------------------------
    # 12. Calculate anomaly threshold
    #     using training data ONLY
    # --------------------------------------------------------

    autoencoder.eval()

    with torch.no_grad():

        reconstructed = autoencoder(
            x_train
        )

        reconstruction_errors = (
            (
                reconstructed
                -
                x_train
            ) ** 2
        ).mean(
            dim=(1, 2)
        ).numpy()

    threshold = float(
        reconstruction_errors.mean()
        +
        3 * reconstruction_errors.std()
    )

    # --------------------------------------------------------
    # 13. Return trained bundle
    # --------------------------------------------------------

    return {

        "forecaster":
            forecaster,

        "autoencoder":
            autoencoder,

        "columns":
            columns,

        "target_index":
            target_index,

        "scaler":
            scaler,

        "threshold":
            threshold,

        "config":
            config,

        # Dataset split information
        "train_size":
            train_size,

        "validation_size":
            validation_size,

        "total_size":
            total_size,

        # Validation data
        "x_validation":
            x_validation,

        "y_validation":
            y_validation,

        # Test data
        "x_test":
            x_test,

        "y_test":
            y_test,
    }


# ============================================================
# ANALYSIS
# ============================================================

def analyze(
    bundle: dict,
    frame
) -> dict:

    columns = bundle[
        "columns"
    ]

    target_index = bundle[
        "target_index"
    ]

    scaler = bundle[
        "scaler"
    ]

    config = bundle[
        "config"
    ]

    values = frame[
        columns
    ].to_numpy(
        dtype=np.float32
    )

    normalized = scaler.transform(
        values
    )

    # --------------------------------------------------------
    # Create sequences for complete dataset
    # --------------------------------------------------------

    x, actual_norm = make_sequences(
        normalized,
        config.lookback,
        target_index
    )

    inputs = torch.tensor(
        x,
        dtype=torch.float32
    )

    bundle[
        "forecaster"
    ].eval()

    bundle[
        "autoencoder"
    ].eval()

    # --------------------------------------------------------
    # Generate predictions and reconstruction errors
    # --------------------------------------------------------

    with torch.no_grad():

        prediction_norm = (
            bundle[
                "forecaster"
            ](
                inputs
            )
            .numpy()
        )

        reconstructed = (
            bundle[
                "autoencoder"
            ](
                inputs
            )
        )

        reconstruction_errors = (
            (
                reconstructed
                -
                inputs
            ) ** 2
        ).mean(
            dim=(1, 2)
        ).numpy()

    # --------------------------------------------------------
    # Convert predictions to original units
    # --------------------------------------------------------

    actual = scaler.inverse_target(
        actual_norm,
        target_index
    )

    expected = scaler.inverse_target(
        prediction_norm,
        target_index
    )

    # --------------------------------------------------------
    # Residual
    # --------------------------------------------------------

    residual = (
        actual
        -
        expected
    )

    # --------------------------------------------------------
    # Performance score
    # --------------------------------------------------------

    denominator = np.maximum(
        np.maximum(
            np.abs(actual),
            np.abs(expected)
        ),
        1e-5
    )

    score = (
        100
        *
        (
            1
            -
            np.abs(residual)
            /
            denominator
        )
    )

    performance_score = np.clip(
        score,
        0,
        100
    )

    # --------------------------------------------------------
    # Identify unseen test portion
    # --------------------------------------------------------

    test_start = (
        bundle[
            "validation_size"
        ]
        -
        config.lookback
    )

    test_actual = actual[
        test_start:
    ]

    test_expected = expected[
        test_start:
    ]

    # --------------------------------------------------------
    # Return analysis results
    # --------------------------------------------------------

    return {

        "actual":
            actual,

        "expected":
            expected,

        "residual":
            residual,

        "test_actual":
            test_actual,

        "test_expected":
            test_expected,

        "validation_actual":
            actual[
                bundle["train_size"] - config.lookback:
                bundle["validation_size"] - config.lookback
            ],

        "validation_expected":
            expected[
                bundle["train_size"] - config.lookback:
                bundle["validation_size"] - config.lookback
            ],

        "anomaly_score":
            reconstruction_errors,

        "anomaly":
            (
                reconstruction_errors
                >
                bundle[
                    "threshold"
                ]
            ),

        "performance_score":
            performance_score,
    }


# ============================================================
# TEST METRICS
# ============================================================

def _calculate_metrics(actual, expected) -> dict[str, float]:
    """Calculate forecasting metrics for one data split."""
    error = actual - expected
    mae = np.mean(np.abs(error))
    mse = np.mean(error ** 2)
    rmse = np.sqrt(mse)

    valid = np.abs(actual) > 1.0
    if np.any(valid):
        mape = np.mean(
            np.abs((actual[valid] - expected[valid]) / actual[valid])
        ) * 100
    else:
        mape = 0.0

    return {
        "mae": float(mae),
        "mse": float(mse),
        "rmse": float(rmse),
        "mape": float(mape),
    }


def metrics(result: dict) -> dict[str, float]:
    """Calculate validation and unseen-test metrics."""
    validation_stats = _calculate_metrics(
        result["validation_actual"],
        result["validation_expected"],
    )
    test_stats = _calculate_metrics(
        result["test_actual"],
        result["test_expected"],
    )

    return {
        "mae": test_stats["mae"],
        "mse": test_stats["mse"],
        "rmse": test_stats["rmse"],
        "mape": test_stats["mape"],
        "validation_mae": validation_stats["mae"],
        "validation_mse": validation_stats["mse"],
        "validation_rmse": validation_stats["rmse"],
        "validation_mape": validation_stats["mape"],
    }


# ============================================================
# WHAT-IF IRRADIANCE SIMULATION
# ============================================================

def what_if(
    bundle: dict,
    recent_frame,
    irradiance_multiplier: float
) -> float:

    if irradiance_multiplier <= 0:
        raise ValueError("Irradiance multiplier must be greater than 0.")

    columns = bundle["columns"]
    config = bundle["config"]

    if "solar_irradiance" not in columns:
        raise ValueError(
            "What-if mode needs a 'solar_irradiance' feature column."
        )

    # The GRU is used to establish the baseline next-step generation.
    # For the scenario itself, use an explicit irradiance-sensitivity
    # assumption so that the scenario has an interpretable direction:
    # 1.20x means 20% higher estimated generation than baseline.
    #
    # This is deliberately a scenario layer, not a physics-based PV model.
    values = recent_frame[columns].to_numpy(dtype=np.float32).copy()
    recent_values = values[-config.lookback:]

    normalized = bundle["scaler"].transform(recent_values)
    x = normalized[None].astype(np.float32)

    bundle["forecaster"].eval()

    with torch.no_grad():
        raw_prediction = bundle["forecaster"](
            torch.tensor(x)
        ).item()

    baseline = bundle["scaler"].inverse_target(
        np.array([raw_prediction]),
        bundle["target_index"]
    )[0]

    baseline = max(float(baseline), 0.0)

    # Transparent scenario assumption:
    # generation scales with the selected recent-irradiance multiplier.
    scenario = baseline * float(irradiance_multiplier)

    return max(float(scenario), 0.0)


# ============================================================
# SAVE MODEL
# ============================================================

def save(
    bundle: dict,
    path: str | Path
) -> None:

    path = Path(path)

    path.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    torch.save(
        {

            "forecaster":
                bundle[
                    "forecaster"
                ].state_dict(),

            "autoencoder":
                bundle[
                    "autoencoder"
                ].state_dict(),

            "columns":
                bundle[
                    "columns"
                ],

            "target_index":
                bundle[
                    "target_index"
                ],

            "mean":
                bundle[
                    "scaler"
                ].mean,

            "std":
                bundle[
                    "scaler"
                ].std,

            "threshold":
                bundle[
                    "threshold"
                ],

            # Dataset split information
            "train_size":
                bundle[
                    "train_size"
                ],

            "validation_size":
                bundle[
                    "validation_size"
                ],

            "total_size":
                bundle[
                    "total_size"
                ],

            "config":
                asdict(
                    bundle[
                        "config"
                    ]
                ),
        },

        path
    )


# ============================================================
# LOAD MODEL
# ============================================================

def load(
    path: str | Path
) -> dict:

    state = torch.load(
        path,
        map_location="cpu",
        weights_only=False
    )

    config = Config(
        **state[
            "config"
        ]
    )

    # --------------------------------------------------------
    # Recreate models
    # --------------------------------------------------------

    forecaster = GRUForecaster(
        len(
            state[
                "columns"
            ]
        ),
        config.hidden_size
    )

    autoencoder = SequenceAutoencoder(
        len(
            state[
                "columns"
            ]
        ),
        config.hidden_size // 2
    )

    # --------------------------------------------------------
    # Load trained weights
    # --------------------------------------------------------

    forecaster.load_state_dict(
        state[
            "forecaster"
        ]
    )

    autoencoder.load_state_dict(
        state[
            "autoencoder"
        ]
    )

    # --------------------------------------------------------
    # Return model bundle
    # --------------------------------------------------------

    return {

        "forecaster":
            forecaster,

        "autoencoder":
            autoencoder,

        "columns":
            state[
                "columns"
            ],

        "target_index":
            state[
                "target_index"
            ],

        "scaler":
            Standardizer(
                state["mean"],
                state["std"]
            ),

        "threshold":
            state[
                "threshold"
            ],

        # Dataset split information
        "train_size":
            state[
                "train_size"
            ],

        "validation_size":
            state[
                "validation_size"
            ],

        "total_size":
            state[
                "total_size"
            ],

        "config":
            config,
    }