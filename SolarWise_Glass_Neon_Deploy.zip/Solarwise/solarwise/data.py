from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd


@dataclass
class Standardizer:
    mean: np.ndarray
    std: np.ndarray

    @classmethod
    def fit(cls, values: np.ndarray) -> "Standardizer":
        mean = values.mean(axis=0)
        std = values.std(axis=0)
        return cls(mean, np.where(std < 1e-8, 1.0, std))

    def transform(self, values: np.ndarray) -> np.ndarray:
        return (values - self.mean) / self.std

    def inverse_target(
        self,
        values: np.ndarray,
        target_index: int
    ) -> np.ndarray:
        return values * self.std[target_index] + self.mean[target_index]


def load_data(path: str | Path, target: str = "solar_power") -> pd.DataFrame:

    frame = pd.read_csv(path)
    frame.columns = frame.columns.str.strip()

    # Rename dataset columns to SolarWise names
    rename_map = {
        "GHI": "solar_irradiance",
        "Temperature": "temperature",
        "Relative Humidity": "humidity",
        "Wind Speed": "wind_speed",
        "Wind Direction": "wind_direction",
        "Hour": "hour",
        "Day": "day",
        "Month": "month",
        "SZ Angle": "solar_zenith_angle",
        "SA Angle": "solar_azimuth_angle",
        "AC Output": "solar_power",
    }

    frame = frame.rename(columns=rename_map)

    # Check target
    if target not in frame.columns:
        raise ValueError(
            f"Target column '{target}' was not found. "
            f"Available columns: {list(frame.columns)}"
        )

    # Sort chronologically
    if "Timestamp" in frame.columns:
        frame["Timestamp"] = pd.to_datetime(
            frame["Timestamp"],
            errors="coerce"
        )
        frame = frame.sort_values("Timestamp")

    # Remove duplicate timestamps
    if "Timestamp" in frame.columns:
        frame = frame.drop_duplicates(subset="Timestamp")

    # Keep numerical columns for the ML model
    numeric = frame.select_dtypes(include="number").copy()

    # Check target
    if target not in numeric.columns:
        raise ValueError(
            f"Target column '{target}' must be numeric."
        )

    # Handle missing values
    numeric = (
        numeric
        .replace([np.inf, -np.inf], np.nan)
        .interpolate(limit_direction="both")
        .ffill()
        .bfill()
    )

    return numeric.reset_index(drop=True)


def make_sequences(
    values: np.ndarray,
    lookback: int,
    target_index: int
) -> tuple[np.ndarray, np.ndarray]:

    if len(values) <= lookback:
        raise ValueError(
            f"Need more than {lookback} records to construct sequences."
        )

    x = np.stack(
        [
            values[i - lookback:i]
            for i in range(lookback, len(values))
        ]
    )

    y = values[lookback:, target_index]

    return x.astype(np.float32), y.astype(np.float32)


def feature_columns(
    frame: pd.DataFrame,
    target: str
) -> list[str]:

    return [
        column for column in frame.columns
        if column != target
    ] + [target]