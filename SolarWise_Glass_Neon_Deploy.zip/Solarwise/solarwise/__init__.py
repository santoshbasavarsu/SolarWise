"""SolarWise forecasting and analytics package."""
