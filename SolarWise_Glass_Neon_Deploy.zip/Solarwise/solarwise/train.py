from __future__ import annotations

import argparse
from pathlib import Path

from solarwise.data import load_data
from solarwise.pipeline import Config, analyze, metrics, save, train


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Train the SolarWise AI model."
    )

    parser.add_argument("--csv", default="data/Solar_Weather_Data_Processed.csv")
    parser.add_argument("--target", default="solar_power")
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--lookback", type=int, default=24)
    parser.add_argument("--output", default="artifacts/solarwise.pt")

    args = parser.parse_args()

    print("Loading dataset...")

    frame = load_data(args.csv, target=args.target)

    print("Dataset loaded successfully.")
    print(f"Rows: {len(frame)}")
    print(f"Columns: {list(frame.columns)}")

    config = Config(
        target=args.target,
        lookback=args.lookback,
        epochs=args.epochs
    )

    print("\nStarting SolarWise AI training...")
    bundle = train(frame, config)

    print("\nRunning analysis...")
    result = analyze(bundle, frame)
    stats = metrics(result)

    print("\nValidation Performance:")
    print("-" * 40)
    print(f"MAE:  {stats['validation_mae']:.4f}")
    print(f"MSE:  {stats['validation_mse']:.4f}")
    print(f"RMSE: {stats['validation_rmse']:.4f}")
    print(f"MAPE: {stats['validation_mape']:.2f}%")

    print("\nTest Performance:")
    print("-" * 40)
    print(f"MAE:  {stats['mae']:.4f}")
    print(f"MSE:  {stats['mse']:.4f}")
    print(f"RMSE: {stats['rmse']:.4f}")
    print(f"MAPE: {stats['mape']:.2f}%")

    print("\nValidation vs Test Comparison:")
    print("-" * 70)
    print(f"{'Metric':<12}{'Validation':>18}{'Test':>18}")
    print("-" * 70)
    print(f"{'MAE':<12}{stats['validation_mae']:>18.4f}{stats['mae']:>18.4f}")
    print(f"{'MSE':<12}{stats['validation_mse']:>18.4f}{stats['mse']:>18.4f}")
    print(f"{'RMSE':<12}{stats['validation_rmse']:>18.4f}{stats['rmse']:>18.4f}")
    print(f"{'MAPE':<12}{stats['validation_mape']:>17.2f}%{stats['mape']:>17.2f}%")

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    save(bundle, output_path)

    print("\nTraining completed successfully!")
    print(f"Model saved to: {output_path}")


if __name__ == "__main__":
    main()
