from __future__ import annotations

from pathlib import Path
import sys

# Make the project root importable even when Streamlit launches this file directly.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from solarwise.data import load_data
from solarwise.pipeline import analyze, load, metrics, what_if


st.set_page_config(
    page_title="SolarWise AI",
    page_icon="☀️",
    layout="wide",
)

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=DM+Sans:wght@400;500;600;700&display=swap');
:root { --sw-cyan:#4cf4ff; --sw-violet:#b77bff; --sw-mint:#7dffd1; --sw-muted:#9bb3cc; }
html, body, [class*="css"] { font-family:'DM Sans',sans-serif; }
.stApp { background: radial-gradient(ellipse at 78% 0%, #20205b 0%, transparent 35%), radial-gradient(ellipse at 0% 30%, #063c50 0%, transparent 38%), linear-gradient(145deg,#050816 0%,#080d20 52%,#08091a 100%); color:#f4f7ff; }
.stApp:before { content:""; position:fixed; inset:0; pointer-events:none; opacity:.12; background-image:linear-gradient(#72f5ff22 1px,transparent 1px),linear-gradient(90deg,#72f5ff22 1px,transparent 1px); background-size:46px 46px; mask-image:linear-gradient(to bottom,#000,transparent 82%); }
.block-container { max-width:1500px; padding-top:1.4rem; padding-bottom:3rem; }
[data-testid="stHeader"] { background:transparent; }
[data-testid="stSidebar"] { background:linear-gradient(180deg,rgba(11,19,44,.96),rgba(7,11,27,.94)); border-right:1px solid #63f5ff25; }
[data-testid="stSidebar"] * { color:#e9f2ff; }
[data-testid="stSidebar"] [data-testid="stFileUploader"] { background:rgba(88,222,255,.05); border:1px solid #62eaff25; border-radius:14px; padding:8px; }
.hero-glass { position:relative; overflow:hidden; padding:28px 30px; border-radius:25px; border:1px solid #7deeff55; background:linear-gradient(115deg,rgba(30,209,255,.13),rgba(125,82,255,.12) 56%,rgba(255,255,255,.035)); box-shadow:0 20px 70px #0007,inset 0 1px 0 #ffffff1a; backdrop-filter:blur(22px); margin-bottom:25px; }
.hero-glass:after { content:""; position:absolute; width:260px;height:260px; right:-45px;top:-105px;border-radius:50%; background:radial-gradient(circle at 35% 35%,#e5fdff 0%,#4cf4ff 8%,#8065ff 34%,transparent 69%); filter:blur(4px);opacity:.58; }
.hero-kicker { color:var(--sw-cyan); font-size:10px; font-weight:700; letter-spacing:3px; text-transform:uppercase; }
.hero-title { font-family:'Space Grotesk',sans-serif; font-size:clamp(32px,4vw,49px); font-weight:700; letter-spacing:-2px; margin:10px 0 7px; line-height:1.05; position:relative;z-index:1; }
.hero-title span { background:linear-gradient(90deg,#62f6ff,#c7a1ff);-webkit-background-clip:text;background-clip:text;color:transparent; }
.hero-sub { max-width:700px;color:#b8c9e5;font-size:13px;line-height:1.75;position:relative;z-index:1;margin:0; }
.hero-orb { position:absolute;right:65px;top:45px;width:110px;height:110px;border:1px solid #72f5ff6b;border-radius:50%;box-shadow:0 0 30px #4cf4ff18,0 0 0 18px #4cf4ff08,0 0 0 38px #b77bff08; }
[data-testid="stMetric"] { background:linear-gradient(140deg,rgba(255,255,255,.09),rgba(255,255,255,.025)); border:1px solid #8aefff2b; border-radius:18px; padding:18px 20px; box-shadow:0 12px 35px #0004,inset 0 1px 0 #ffffff12; backdrop-filter:blur(18px); min-height:112px; }
[data-testid="stMetricLabel"] { color:#a9bed8 !important; font-size:12px; }
[data-testid="stMetricValue"] { color:#f5fbff !important; font-family:'Space Grotesk',sans-serif; text-shadow:0 0 22px #4cf4ff20; }
[data-testid="stMetricDelta"] { color:var(--sw-mint) !important; }
[data-testid="stTabs"] [data-baseweb="tab-list"] { gap:7px; background:rgba(4,9,24,.46);border:1px solid #81eaff20;padding:7px;border-radius:15px; }
[data-testid="stTabs"] button[role="tab"] { border-radius:10px;color:#a9bdd7;padding:9px 15px; }
[data-testid="stTabs"] button[role="tab"][aria-selected="true"] { color:#07101f;background:linear-gradient(100deg,#56f2ff,#b6a0ff);font-weight:700;box-shadow:0 0 22px #4cf4ff26; }
[data-testid="stPlotlyChart"], [data-testid="stDataFrame"] { background:linear-gradient(145deg,rgba(255,255,255,.055),rgba(255,255,255,.015));border:1px solid #8aefff20;border-radius:18px;padding:8px; }
[data-testid="stAlert"] { border-radius:14px; background:rgba(63,206,255,.08); }
.stButton button, .stDownloadButton button { border-radius:12px;border:1px solid #62f2ff55;background:linear-gradient(110deg,#1ab8d51c,#956bff20);color:#eafaff; }
.stButton button:hover, .stDownloadButton button:hover { border-color:#72f5ff;box-shadow:0 0 22px #4cf4ff1a;color:#fff; }
h1,h2,h3 { font-family:'Space Grotesk',sans-serif !important;letter-spacing:-.5px; }
hr { border-color:#8aefff20; }
small, .stCaption { color:#94abc7 !important; }
@media(max-width:700px){.hero-glass{padding:22px 20px}.hero-orb{right:-20px;opacity:.5}.hero-title{font-size:34px}.block-container{padding-left:1rem;padding-right:1rem}}
</style>
<div class="hero-glass">
  <div class="hero-kicker">✦ Solar intelligence platform</div>
  <div class="hero-title">Solar<span>Wise</span> AI</div>
  <p class="hero-sub">Forecast solar generation, surface unusual patterns, and explore performance scenarios — powered by deep learning in a neon glass dashboard.</p>
  <div class="hero-orb"></div>
</div>
""", unsafe_allow_html=True)

# --------------------------------------------------
# Paths and model
# --------------------------------------------------

model_path = PROJECT_ROOT / "artifacts" / "solarwise.pt"
default_data_path = PROJECT_ROOT / "data" / "Solar_Weather_Data_Processed.csv"

if not model_path.exists():
    st.error("Trained model not found. Train the project first with:")
    st.code("python -m solarwise.train --epochs 30")
    st.stop()

@st.cache_resource
def load_model(model_file):
    return load(model_file)

@st.cache_data
def load_project_data(data_file, target):
    return load_data(data_file, target)

bundle = load_model(model_path)

# --------------------------------------------------
# Sidebar
# --------------------------------------------------

st.sidebar.header("SolarWise Controls")

uploaded = st.sidebar.file_uploader(
    "Optional input CSV",
    type="csv",
    help="Upload a compatible solar/weather CSV for inference."
)

if uploaded is None:
    frame = load_project_data(default_data_path, bundle["config"].target)
    using_default = True
else:
    frame = load_data(uploaded, bundle["config"].target)
    using_default = False

st.sidebar.caption(
    "Using bundled dataset" if using_default else "Using uploaded dataset"
)

# --------------------------------------------------
# Analysis
# --------------------------------------------------

result = analyze(bundle, frame)
stats = metrics(result)

test_actual = np.asarray(result["test_actual"])
test_expected = np.asarray(result["test_expected"])

anomaly = np.asarray(result["anomaly"], dtype=bool)
anomaly_score = np.asarray(result["anomaly_score"])
performance_score = np.asarray(result["performance_score"])

test_mae = stats["mae"]
test_rmse = stats["rmse"]
test_mape = stats["mape"]

anomaly_count = int(anomaly.sum())
anomaly_rate = anomaly_count / len(anomaly) * 100 if len(anomaly) else 0.0
avg_performance = float(np.mean(performance_score))
median_performance = float(np.median(performance_score))

# --------------------------------------------------
# Top-level KPIs
# --------------------------------------------------

st.subheader("Model Performance")

k1, k2, k3, k4 = st.columns(4)
k1.metric("Test MAE", f"{test_mae:.2f}")
k2.metric("Test RMSE", f"{test_rmse:.2f}")
k3.metric("Test MAPE", f"{test_mape:.2f}%")
k4.metric("Anomaly Rate", f"{anomaly_rate:.2f}%")

st.caption(
    "Forecast metrics are calculated on the unseen test portion of the "
    "bundled dataset. MAPE excludes observations where absolute actual "
    "generation is ≤ 1.0."
)

# --------------------------------------------------
# Tabs
# --------------------------------------------------

overview_tab, forecast_tab, anomaly_tab, performance_tab, whatif_tab, data_tab = st.tabs(
    [
        "Overview",
        "Forecast",
        "Anomalies",
        "Performance",
        "What-if",
        "Data Explorer",
    ]
)

# --------------------------------------------------
# Overview
# --------------------------------------------------

with overview_tab:
    st.subheader("SolarWise Overview")

    c1, c2, c3 = st.columns(3)
    c1.metric("Dataset Rows", f"{len(frame):,}")
    c2.metric("Forecast Lookback", f"{bundle['config'].lookback} observations")
    c3.metric("Average Performance Score", f"{avg_performance:.2f}/100")

    st.markdown(
        """
        **SolarWise** combines four analytical tasks:

        - **Forecasting:** GRU-based next-step solar-power prediction.
        - **Anomaly detection:** sequence autoencoder reconstruction error.
        - **Performance analysis:** actual-vs-expected residuals and a 0–100 score.
        - **Scenario simulation:** estimate the next output under a changed irradiance level.
        """
    )

    st.info(
        "For a clean project demonstration, use the bundled dataset first. "
        "Uploaded datasets should contain the same required feature structure."
    )

# --------------------------------------------------
# Forecast
# --------------------------------------------------

with forecast_tab:
    st.subheader("Actual vs Expected Solar Generation")

    window = st.select_slider(
        "Observations to display",
        options=[50, 100, 200, 500, 1000],
        value=200,
        help="A shorter window makes forecast behavior easier to inspect.",
    )

    display_actual = test_actual[-window:]
    display_expected = test_expected[-window:]

    # Map anomaly indices into the test portion for the selected window.
    test_start_index = len(result["actual"]) - len(test_actual)
    anomaly_test = anomaly[test_start_index:]
    anomaly_test_window = anomaly_test[-window:]

    fig = go.Figure()
    x = np.arange(len(display_actual))

    fig.add_scatter(
        x=x,
        y=display_actual,
        name="Actual solar power",
        mode="lines",
    )
    fig.add_scatter(
        x=x,
        y=display_expected,
        name="Expected solar power",
        mode="lines",
    )

    anomaly_x = x[anomaly_test_window]
    anomaly_y = display_actual[anomaly_test_window]

    fig.add_scatter(
        x=anomaly_x,
        y=anomaly_y,
        mode="markers",
        name="Anomaly",
        marker={"size": 9},
    )

    fig.update_layout(
        height=500,
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(4,10,27,0.18)",
        font={"color": "#c9d8f0", "family": "DM Sans"},
        colorway=["#4cf4ff", "#b77bff", "#7dffd1", "#ff78d1"],
        xaxis_title="Test observation",
        yaxis_title="Solar power",
        hovermode="x unified",
        margin={"l": 20, "r": 20, "t": 30, "b": 20},
    )

    st.plotly_chart(fig, use_container_width=True)

    st.caption(
        "Only the unseen test portion is shown here so the forecasting "
        "visualization matches the reported test metrics."
    )

# --------------------------------------------------
# Anomalies
# --------------------------------------------------

with anomaly_tab:
    st.subheader("Anomaly Detection")

    a1, a2, a3 = st.columns(3)
    a1.metric("Detected Anomalies", f"{anomaly_count:,}")
    a2.metric("Anomaly Rate", f"{anomaly_rate:.2f}%")
    a3.metric("Threshold", f"{bundle['threshold']:.4f}")

    anomaly_fig = go.Figure()
    anomaly_fig.add_scatter(
        y=anomaly_score,
        mode="lines",
        name="Reconstruction error",
    )
    anomaly_fig.add_hline(
        y=bundle["threshold"],
        line_dash="dash",
        annotation_text="Anomaly threshold",
    )
    anomaly_fig.update_layout(
        height=420,
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(4,10,27,0.18)",
        font={"color": "#c9d8f0", "family": "DM Sans"},
        colorway=["#4cf4ff", "#b77bff", "#7dffd1", "#ff78d1"],
        xaxis_title="Observation",
        yaxis_title="Reconstruction error",
    )
    st.plotly_chart(anomaly_fig, use_container_width=True)

    st.caption(
        "The anomaly threshold is derived from training reconstruction "
        "error as mean + 3 standard deviations."
    )

# --------------------------------------------------
# Performance
# --------------------------------------------------

with performance_tab:
    st.subheader("Solar Performance Score")

    p1, p2, p3 = st.columns(3)
    p1.metric("Average Score", f"{avg_performance:.2f}/100")
    p2.metric("Median Score", f"{median_performance:.2f}/100")
    p3.metric(
        "Low-Performance Observations",
        f"{int(np.sum(performance_score < 50)):,}",
    )

    score_fig = go.Figure()
    score_fig.add_scatter(
        y=performance_score,
        mode="lines",
        name="Performance score",
    )

    for level, label in [(80, "Good"), (60, "Moderate"), (40, "Poor")]:
        score_fig.add_hline(
            y=level,
            line_dash="dash",
            annotation_text=f"{label} ({level})",
        )

    score_fig.update_layout(
        height=430,
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(4,10,27,0.18)",
        font={"color": "#c9d8f0", "family": "DM Sans"},
        colorway=["#4cf4ff", "#b77bff", "#7dffd1", "#ff78d1"],
        yaxis_range=[0, 100],
        xaxis_title="Observation",
        yaxis_title="Score",
    )

    st.plotly_chart(score_fig, use_container_width=True)

    st.caption(
        "The score is based on relative absolute residual error: larger "
        "deviations between actual and expected generation produce lower scores."
    )

# --------------------------------------------------
# What-if
# --------------------------------------------------

with whatif_tab:
    st.subheader("Irradiance What-if Simulation")

    multiplier = st.slider(
        "Irradiance multiplier",
        min_value=0.40,
        max_value=1.60,
        value=1.00,
        step=0.05,
        help=(
            "1.00× is the baseline. 1.20× represents a scenario with "
            "20% higher recent irradiance."
        ),
    )

    try:
        baseline = what_if(bundle, frame, 1.0)
        simulated = what_if(bundle, frame, multiplier)

        change = simulated - baseline
        change_pct = (change / abs(baseline) * 100) if abs(baseline) > 1e-8 else 0.0

        w1, w2, w3 = st.columns(3)
        w1.metric("Baseline Output", f"{baseline:.2f}")
        w2.metric("Scenario Output", f"{simulated:.2f}")
        w3.metric("Scenario Change", f"{change:+.2f} ({change_pct:+.2f}%)")

        st.info(
            f"{multiplier:.2f}× means the scenario assumes estimated "
            f"generation changes proportionally with recent irradiance. "
            "The GRU supplies the baseline; the scenario layer applies "
            "the selected multiplier. This is a transparent scenario "
            "estimate, not a physics-based photovoltaic model."
        )

    except ValueError as error:
        st.warning(str(error))

# --------------------------------------------------
# Data Explorer
# --------------------------------------------------

with data_tab:
    st.subheader("Data Explorer")

    st.write(
        f"Showing the latest 20 rows of the analyzed dataset ({len(frame):,} rows total)."
    )

    analysis_df = pd.DataFrame(
        {
            "actual": result["actual"],
            "expected": result["expected"],
            "residual": result["residual"],
            "anomaly_score": result["anomaly_score"],
            "anomaly": result["anomaly"],
            "performance_score": result["performance_score"],
        }
    )

    st.dataframe(
        analysis_df.tail(20),
        use_container_width=True,
    )

    st.subheader("Residual Distribution")

    residual_fig = go.Figure()
    residual_fig.add_histogram(
        x=result["residual"],
        nbinsx=40,
        name="Residual",
    )
    residual_fig.update_layout(
        height=380,
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(4,10,27,0.18)",
        font={"color": "#c9d8f0", "family": "DM Sans"},
        colorway=["#4cf4ff", "#b77bff", "#7dffd1", "#ff78d1"],
        xaxis_title="Actual − Expected",
        yaxis_title="Count",
    )
    st.plotly_chart(residual_fig, use_container_width=True)