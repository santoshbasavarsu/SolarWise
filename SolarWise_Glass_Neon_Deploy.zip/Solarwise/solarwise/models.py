from __future__ import annotations

import torch
from torch import nn


class GRUForecaster(nn.Module):
    def __init__(self, input_size: int, hidden_size: int = 64, layers: int = 2) -> None:
        super().__init__()
        self.gru = nn.GRU(input_size, hidden_size, num_layers=layers, batch_first=True, dropout=0.1 if layers > 1 else 0)
        self.head = nn.Sequential(nn.Linear(hidden_size, 32), nn.ReLU(), nn.Linear(32, 1))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        output, _ = self.gru(x)
        return self.head(output[:, -1]).squeeze(-1)


class SequenceAutoencoder(nn.Module):
    def __init__(self, input_size: int, hidden_size: int = 32) -> None:
        super().__init__()
        self.encoder = nn.GRU(input_size, hidden_size, batch_first=True)
        self.decoder = nn.GRU(hidden_size, hidden_size, batch_first=True)
        self.output = nn.Linear(hidden_size, input_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        _, hidden = self.encoder(x)
        repeated = hidden[-1].unsqueeze(1).repeat(1, x.size(1), 1)
        decoded, _ = self.decoder(repeated)
        return self.output(decoded)
