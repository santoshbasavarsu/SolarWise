# Publish SolarWise Glass Neon on Streamlit Community Cloud

This project is prepared for Streamlit Community Cloud. The redesign keeps the existing GRU forecasting, sequence-autoencoder anomaly analysis, performance score, scenario estimator, and data explorer.

## 1. Upload to GitHub
1. Create a new GitHub repository, for example `solarwise-glass-neon`.
2. Upload the contents of this `Solarwise` folder to the repository root (including `.streamlit/config.toml`).
3. Ensure `artifacts/solarwise.pt` and `data/Solar_Weather_Data_Processed.csv` are included. Do not commit private data or secrets.

## 2. Deploy
1. Sign in to https://share.streamlit.io/ with your GitHub account.
2. Choose **Create app** and select the repository and branch.
3. Set **Main file path** to `solarwise/app.py`.
4. Deploy. The first startup may take a few minutes because PyTorch and the bundled model need to load.

## 3. Requirements
The app dependencies are listed in `requirements.txt`. If deployment fails because the environment runs out of memory or the PyTorch wheel cannot be installed, inspect the Streamlit build logs and adjust the dependency versions for the selected Python runtime.

## Run locally
From this folder:

```bash
python -m pip install -r requirements.txt
streamlit run solarwise/app.py
```

The public URL is assigned by Streamlit after a successful deployment; it cannot be pre-created from this source ZIP alone.
