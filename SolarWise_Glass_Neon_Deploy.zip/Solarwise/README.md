# SolarWise AI

SolarWise AI is an end-to-end solar-power analytics system that combines next-step forecasting, anomaly detection, residual analysis, a solar performance score, and irradiation what-if simulation in a Streamlit dashboard.

## Core workflow
1. Load and clean solar/weather data.
2. Rename source columns to SolarWise feature names.
3. Sort chronologically and remove duplicate timestamps.
4. Interpolate/fill missing numerical values.
5. Use a chronological 70/15/15 train-validation-test split.
6. Fit the standardizer on training data only.
7. Build 24-hour temporal sequences.
8. Train a GRU forecaster with MSE loss and Adam optimization.
9. Train a GRU sequence autoencoder on training sequences.
10. Set the anomaly threshold from training reconstruction error (mean + 3 standard deviations).
11. Compare actual and expected generation using residual analysis.
12. Calculate a Solar Performance Score from relative residual error.
13. Simulate the next-step output under different recent-irradiance multipliers.
14. Explore the results through the Streamlit dashboard.

## Project structure
```text
Solarwise/
├── artifacts/
│   └── solarwise.pt
├── data/
│   └── Solar_Weather_Data_Processed.csv
├── solarwise/
│   ├── __init__.py
│   ├── app.py
│   ├── data.py
│   ├── models.py
│   ├── pipeline.py
│   └── train.py
├── requirements.txt
└── README.md
```

## Installation
```powershell
python -m pip install -r requirements.txt
```

## Run the bundled model
```powershell
streamlit run solarwise/app.py
```

## Retrain
```powershell
python -m solarwise.train --csv data/Solar_Weather_Data_Processed.csv --target solar_power --epochs 30
```

## Current bundled evaluation
| Metric | Validation | Unseen Test |
|---|---:|---:|
| MAE | 72.8663 | 70.9907 |
| MSE | 18,258.21 | 15,701.98 |
| RMSE | 135.1229 | 125.3076 |
| MAPE* | 41.28% | 44.36% |

*MAPE is calculated only where the absolute actual output is greater than 1.0.

## Notes
The bundled artifact uses a 24-hour lookback, hidden size 64, batch size 64, learning rate 0.001, and 30 training epochs. The what-if module is a scenario simulation rather than a physical solar-plant model.
